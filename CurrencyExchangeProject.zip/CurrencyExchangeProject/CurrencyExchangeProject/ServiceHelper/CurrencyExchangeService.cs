﻿using CurrencyExchangeProject.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;


namespace CurrencyExchangeProject.ServiceHelper
{
    public class CurrencyExchangeService : ICurrencyExchangeService
    {
        public List<CurrencyModel> CurrencyExchangeAPICall()
        {
            var result = string.Empty;
            List<CurrencyModel> currencyList = new List<CurrencyModel>();
            try
            {
                //Creating a webRequest object
                HttpWebRequest _webRequest = WebRequest.Create("https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies/aud.json") as HttpWebRequest;
                _webRequest.Method = "GET";

                using (WebResponse response = _webRequest.GetResponse())
                {
                    using (Stream objStream = response.GetResponseStream())
                    {
                        using (StreamReader reader = new StreamReader(objStream))
                        {
                            result = reader.ReadToEnd();
                        }
                    }
                }

                //Reading API response and mapping to a Dictionary
                dynamic jsonData = JsonConvert.DeserializeObject<dynamic>(result);
                Dictionary<string, decimal> dictionary = jsonData.aud.ToObject<Dictionary<string, decimal>>();

                //Mapping Dicctionary values to a class object
                foreach (var item in dictionary)
                {
                    CurrencyModel currencyObj = new CurrencyModel();
                    currencyObj.CurrencyCode = item.Key;
                    currencyObj.ExchangeRates = item.Value;
                    currencyList.Add(currencyObj);
                }

                return currencyList;
            }
            catch (WebException webEx)
            {
                Console.WriteLine("WebException - " + webEx.StackTrace);
                return currencyList;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception - " + ex.StackTrace);
                return currencyList;
            }
        }


    }
}

﻿using System.Collections.Generic;
using CurrencyExchangeProject.Models;

namespace CurrencyExchangeProject.ServiceHelper
{
    public interface ICurrencyExchangeService
    {
        List<CurrencyModel> CurrencyExchangeAPICall();
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyExchangeProject.Models
{
    public class CurrencyModel
    {
        public string CurrencyCode { get; set; }
        public decimal ExchangeRates { get; set; }
    }
}

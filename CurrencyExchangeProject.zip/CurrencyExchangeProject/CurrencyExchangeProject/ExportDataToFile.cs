﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyExchangeProject
{
    public class ExportDataToFile
    {
        public static void PrintDataToFile(string path, string data)
        {
            //Writing data to a File
            using (StreamWriter file = new StreamWriter(path, true))
            {
                file.WriteLine(data + ",");
            }
        }
    }
}

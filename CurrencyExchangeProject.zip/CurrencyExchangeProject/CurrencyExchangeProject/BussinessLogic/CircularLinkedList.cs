﻿using CurrencyExchangeProject.Models;
using System;
using System.Collections.Generic;

namespace CurrencyExchangeProject.BussinessLogic
{
    public class CircularLinkedList : ICircularLinkedList
    {
        public NodeList InsertIntoCircularLinekedList(List<CurrencyModel> currencyList)
        {
            NodeList cl = new NodeList();

            //Adding data to the list Circular Linked List  
            foreach (CurrencyModel model in currencyList)
            {
                cl.add(model);
            }

            //cl.display();
            //Console.ReadKey();

            return cl;
        }

    }


    //Represents the node of list.  
    public class Node<CurrencyModel>
    {
        public CurrencyModel data;
        public Node<CurrencyModel> next;
        public Node(CurrencyModel value)
        {
            data = value;
            next = null;
        }
    }

    public class NodeList
    {
        public Node<CurrencyModel> head = null;
        public Node<CurrencyModel> tail = null;

        //This function will add the new node at the end of the list.  
        public void add(CurrencyModel data)
        {
            //Create new node  
            Node<CurrencyModel> newNode = new Node<CurrencyModel>(data);
            //Checks if the list is empty.  
            if (head == null)
            {
                head = newNode;
                tail = newNode;
                newNode.next = head;
            }
            else
            {
                //tail will point to new node.  
                tail.next = newNode;
                //New node will become new tail.  
                tail = newNode;
                //Since, it is circular linked list tail will point to head.  
                tail.next = head;
            }
        }

        //Displays all the nodes in the list  
        public void display()
        {
            Node<CurrencyModel> current;
            if (head == null)
            {
                Console.WriteLine("List is empty");
            }
            else
            {
                Console.WriteLine("Nodes of the circular linked list: ");
                Console.WriteLine(" " + head.data.GetType().GetProperty("CurrencyCode").GetValue(head.data) + " - " + head.data.GetType().GetProperty("ExchangeRates").GetValue(head.data));
                for (current = head.next; current != head; current = current.next)
                {
                    Console.WriteLine(" " + current.data.GetType().GetProperty("CurrencyCode").GetValue(current.data) + " - " + current.data.GetType().GetProperty("ExchangeRates").GetValue(current.data));
                }
            }
        }
    }



}

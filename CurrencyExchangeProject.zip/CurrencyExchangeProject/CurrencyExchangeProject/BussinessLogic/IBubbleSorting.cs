﻿namespace CurrencyExchangeProject.BussinessLogic
{
    public interface IBubbleSorting
    {
        void display(NodeList cl);
        void sortCircularLinkedList(NodeList cl);
    }
}
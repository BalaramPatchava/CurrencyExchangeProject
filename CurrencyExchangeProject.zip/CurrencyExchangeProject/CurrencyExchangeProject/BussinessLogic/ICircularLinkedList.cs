﻿using System.Collections.Generic;
using CurrencyExchangeProject.Models;

namespace CurrencyExchangeProject.BussinessLogic
{
    public interface ICircularLinkedList
    {
        NodeList InsertIntoCircularLinekedList(List<CurrencyModel> currencyList);
    }
}
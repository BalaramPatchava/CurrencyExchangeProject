﻿using CurrencyExchangeProject.Models;
using System;
using System.IO;


namespace CurrencyExchangeProject.BussinessLogic
{
    public class BubbleSorting : IBubbleSorting
    {
        //Soritng CircularLinkedList using BubbleSort and Display data to user
        public void sortCircularLinkedList(NodeList cl)
        {
            //Current will point to head  
            Node<CurrencyModel> current = cl.head, index = null;
            CurrencyModel temp;
            if (cl.head == null)
            {
                Console.WriteLine("List is empty");
            }
            else
            {
                do
                {
                    //Index will point to node next to current  
                    index = current.next;
                    while (index != cl.head)
                    {
                        //sorting based on ExchangeRates
                        if (current.data.ExchangeRates.CompareTo(index.data.ExchangeRates) > 0)
                        {
                            temp = current.data;
                            current.data = index.data;
                            index.data = temp;
                        }
                        else if (current.data.ExchangeRates == index.data.ExchangeRates)
                        {
                            //sorting based on CurrencyCode
                            if(current.data.CurrencyCode.CompareTo(index.data.CurrencyCode) > 0)
                            {
                                temp = current.data;
                                current.data = index.data;
                                index.data = temp;
                            }
                        }

                        index = index.next;
                    }
                    current = current.next;
                } while (current.next != cl.head);
            }

            // Display Node values
            display(cl);
        }

        //Displays all the nodes in the CirucularLinkedlist
        //Printing data to CSV file
        public void display(NodeList cl)
        {
            Node<CurrencyModel> current = cl.head;
            if (cl.head == null)
            {
                Console.WriteLine("List is empty");
            }
            else
            {
                string path = ".\\CSVFiles\\CSVFile.txt";
                File.WriteAllText(path, String.Empty);
                do
                {
                    string data = current.data.CurrencyCode + " - " + current.data.ExchangeRates;
                    //Printing CurrencyCode and Exchange rates
                    Console.WriteLine(" " + data);

                    //Writing data to a File
                    ExportDataToFile.PrintDataToFile(path, data);

                    current = current.next;
                } while (current != cl.head);

                Console.WriteLine();
            }

            ////Writing sorted data to a CSV file
            //File.WriteAllLines("text.txt", lst.Select(x => string.Join(",", x)));
        }
    }
}



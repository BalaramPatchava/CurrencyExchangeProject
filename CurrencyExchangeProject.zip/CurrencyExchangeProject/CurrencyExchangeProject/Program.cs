﻿using CurrencyExchangeProject.BussinessLogic;
using CurrencyExchangeProject.Models;
using CurrencyExchangeProject.ServiceHelper;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;


namespace CurrencyExchangeProject
{
    public class Program
    {
        private static ICircularLinkedList circularLinkedList;
        private static ICurrencyExchangeService currencyExchangeService;
        private static IBubbleSorting bubbleSorting;

        public static void Main(string[] args)
        {
            //Dependency Injection
            var serviceProvider = new ServiceCollection()
                .AddSingleton<ICurrencyExchangeService, CurrencyExchangeService>()
                .AddSingleton<ICircularLinkedList, CircularLinkedList>()
                .AddSingleton<IBubbleSorting, BubbleSorting>()
                .BuildServiceProvider();

            currencyExchangeService = serviceProvider.GetService<ICurrencyExchangeService>();
            circularLinkedList = serviceProvider.GetService<ICircularLinkedList>();
            bubbleSorting = serviceProvider.GetService<IBubbleSorting>();

            //Calling Currency Exchange API and getting results
            List<CurrencyModel> currencyList = currencyExchangeService.CurrencyExchangeAPICall();

            //Storing results into Circular Linked List
            NodeList cl = circularLinkedList.InsertIntoCircularLinekedList(currencyList);

            //Sorting Values in Circular Linked List values using Bubble sort and Display data
            //Printing sorted list to a CSV file
            bubbleSorting.sortCircularLinkedList(cl);

            Console.ReadKey();
        }
    }
}
